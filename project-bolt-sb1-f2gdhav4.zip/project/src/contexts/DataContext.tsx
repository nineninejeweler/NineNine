import React, { createContext, useContext, useState, useEffect } from 'react';

export interface Consignee {
  id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  address: string;
  businessName: string;
  commission: number;
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  description: string;
  image?: string;
  createdAt: string;
}

export interface ConsignmentItem {
  id: string;
  productId: string;
  consigneeId: string;
  quantity: number;
  status: 'consigned' | 'sold' | 'returned';
  consignedAt: string;
}

export interface Sale {
  id: string;
  consigneeId: string;
  productId: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  commission: number;
  paymentMethod: 'cash' | 'card' | 'pix' | 'installments';
  installments?: number;
  saleDate: string;
}

interface DataContextType {
  consignees: Consignee[];
  products: Product[];
  consignmentItems: ConsignmentItem[];
  sales: Sale[];
  addConsignee: (consignee: Omit<Consignee, 'id' | 'createdAt'>) => void;
  updateConsignee: (id: string, consignee: Partial<Consignee>) => void;
  deleteConsignee: (id: string) => void;
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addConsignmentItem: (item: Omit<ConsignmentItem, 'id' | 'consignedAt'>) => void;
  updateConsignmentItem: (id: string, item: Partial<ConsignmentItem>) => void;
  addSale: (sale: Omit<Sale, 'id' | 'saleDate'>) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [consignees, setConsignees] = useState<Consignee[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [consignmentItems, setConsignmentItems] = useState<ConsignmentItem[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);

  useEffect(() => {
    // Carregar dados do localStorage
    const savedConsignees = localStorage.getItem('consignees');
    const savedProducts = localStorage.getItem('products');
    const savedConsignmentItems = localStorage.getItem('consignmentItems');
    const savedSales = localStorage.getItem('sales');

    if (savedConsignees) setConsignees(JSON.parse(savedConsignees));
    if (savedProducts) setProducts(JSON.parse(savedProducts));
    if (savedConsignmentItems) setConsignmentItems(JSON.parse(savedConsignmentItems));
    if (savedSales) setSales(JSON.parse(savedSales));
  }, []);

  useEffect(() => {
    localStorage.setItem('consignees', JSON.stringify(consignees));
  }, [consignees]);

  useEffect(() => {
    localStorage.setItem('products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('consignmentItems', JSON.stringify(consignmentItems));
  }, [consignmentItems]);

  useEffect(() => {
    localStorage.setItem('sales', JSON.stringify(sales));
  }, [sales]);

  const addConsignee = (consignee: Omit<Consignee, 'id' | 'createdAt'>) => {
    const newConsignee: Consignee = {
      ...consignee,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setConsignees(prev => [...prev, newConsignee]);
  };

  const updateConsignee = (id: string, consignee: Partial<Consignee>) => {
    setConsignees(prev => prev.map(c => c.id === id ? { ...c, ...consignee } : c));
  };

  const deleteConsignee = (id: string) => {
    setConsignees(prev => prev.filter(c => c.id !== id));
  };

  const addProduct = (product: Omit<Product, 'id' | 'createdAt'>) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, product: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...product } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const addConsignmentItem = (item: Omit<ConsignmentItem, 'id' | 'consignedAt'>) => {
    const newItem: ConsignmentItem = {
      ...item,
      id: Date.now().toString(),
      consignedAt: new Date().toISOString()
    };
    setConsignmentItems(prev => [...prev, newItem]);
  };

  const updateConsignmentItem = (id: string, item: Partial<ConsignmentItem>) => {
    setConsignmentItems(prev => prev.map(i => i.id === id ? { ...i, ...item } : i));
  };

  const addSale = (sale: Omit<Sale, 'id' | 'saleDate'>) => {
    const newSale: Sale = {
      ...sale,
      id: Date.now().toString(),
      saleDate: new Date().toISOString()
    };
    setSales(prev => [...prev, newSale]);
  };

  return (
    <DataContext.Provider value={{
      consignees,
      products,
      consignmentItems,
      sales,
      addConsignee,
      updateConsignee,
      deleteConsignee,
      addProduct,
      updateProduct,
      deleteProduct,
      addConsignmentItem,
      updateConsignmentItem,
      addSale
    }}>
      {children}
    </DataContext.Provider>
  );
};