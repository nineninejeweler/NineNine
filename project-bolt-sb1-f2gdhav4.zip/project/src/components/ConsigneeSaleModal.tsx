import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { X } from 'lucide-react';

interface ConsigneeSaleModalProps {
  consigneeId: string;
  onClose: () => void;
}

const ConsigneeSaleModal: React.FC<ConsigneeSaleModalProps> = ({ consigneeId, onClose }) => {
  const { addSale, consignees, products, consignmentItems, updateConsignmentItem } = useData();
  const [formData, setFormData] = useState({
    productId: '',
    quantity: 1,
    paymentMethod: 'cash' as 'cash' | 'card' | 'pix' | 'installments',
    installments: 1,
  });

  const consignee = consignees.find(c => c.id === consigneeId);
  const availableProducts = consignmentItems
    .filter(item => item.consigneeId === consigneeId && item.status === 'consigned')
    .map(item => {
      const product = products.find(p => p.id === item.productId);
      return { ...item, product };
    })
    .filter(item => item.product);

  const selectedItem = availableProducts.find(item => item.productId === formData.productId);
  const selectedProduct = selectedItem?.product;

  const totalPrice = selectedProduct ? formData.quantity * selectedProduct.price : 0;
  const commission = consignee ? (totalPrice * consignee.commission) / 100 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedProduct || !selectedItem) return;

    // Registrar a venda
    addSale({
      consigneeId,
      productId: formData.productId,
      quantity: formData.quantity,
      unitPrice: selectedProduct.price,
      totalPrice,
      commission,
      paymentMethod: formData.paymentMethod,
      installments: formData.paymentMethod === 'installments' ? formData.installments : undefined,
    });

    // Atualizar o item de consignação
    const newQuantity = selectedItem.quantity - formData.quantity;
    if (newQuantity <= 0) {
      updateConsignmentItem(selectedItem.id, { status: 'sold', quantity: 0 });
    } else {
      updateConsignmentItem(selectedItem.id, { quantity: newQuantity });
    }
    
    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? Number(value) : value
    }));
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-900">Registrar Venda</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Produto
            </label>
            <select
              name="productId"
              value={formData.productId}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            >
              <option value="">Selecione um produto</option>
              {availableProducts.map(item => (
                <option key={item.id} value={item.productId}>
                  {item.product?.name} - Estoque: {item.quantity} - {formatCurrency(item.product?.price || 0)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantidade
            </label>
            <input
              type="number"
              name="quantity"
              value={formData.quantity}
              onChange={handleChange}
              min="1"
              max={selectedItem?.quantity || 1}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            />
            {selectedItem && (
              <p className="text-xs text-gray-500 mt-1">
                Disponível: {selectedItem.quantity} unidades
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Forma de Pagamento
            </label>
            <select
              name="paymentMethod"
              value={formData.paymentMethod}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            >
              <option value="cash">Dinheiro</option>
              <option value="card">Cartão</option>
              <option value="pix">PIX</option>
              <option value="installments">Parcelado</option>
            </select>
          </div>

          {formData.paymentMethod === 'installments' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Número de Parcelas
              </label>
              <input
                type="number"
                name="installments"
                value={formData.installments}
                onChange={handleChange}
                min="2"
                max="12"
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              />
            </div>
          )}

          {/* Summary */}
          {selectedProduct && formData.quantity > 0 && (
            <div className="bg-gray-50 p-4 rounded-lg space-y-2">
              <h3 className="font-medium text-gray-900">Resumo da Venda</h3>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Valor Total:</span>
                  <span>{formatCurrency(totalPrice)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Sua Comissão ({consignee?.commission}%):</span>
                  <span className="text-green-600 font-medium">{formatCurrency(commission)}</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!selectedProduct || formData.quantity <= 0}
              className="flex-1 px-4 py-2 bg-yellow-500 text-gray-900 rounded-lg hover:bg-yellow-600 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Registrar Venda
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ConsigneeSaleModal;