import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { BarChart3, TrendingUp, Calendar, DollarSign, Users, Package } from 'lucide-react';

const Estatisticas: React.FC = () => {
  const { sales, consignees, products } = useData();
  const [period, setPeriod] = useState('30'); // days

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const getFilteredSales = () => {
    const days = parseInt(period);
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return sales.filter(sale => new Date(sale.saleDate) >= cutoffDate);
  };

  const filteredSales = getFilteredSales();

  // Estatísticas gerais
  const totalRevenue = filteredSales.reduce((sum, sale) => sum + sale.totalPrice, 0);
  const totalCommissions = filteredSales.reduce((sum, sale) => sum + sale.commission, 0);
  const netProfit = totalRevenue - totalCommissions;
  const averageTicket = filteredSales.length > 0 ? totalRevenue / filteredSales.length : 0;

  // Top consignatários
  const consigneeStats = consignees.map(consignee => {
    const consigneeSales = filteredSales.filter(sale => sale.consigneeId === consignee.id);
    const revenue = consigneeSales.reduce((sum, sale) => sum + sale.totalPrice, 0);
    const commission = consigneeSales.reduce((sum, sale) => sum + sale.commission, 0);
    
    return {
      ...consignee,
      salesCount: consigneeSales.length,
      revenue,
      commission
    };
  }).sort((a, b) => b.revenue - a.revenue);

  // Top produtos
  const productStats = products.map(product => {
    const productSales = filteredSales.filter(sale => sale.productId === product.id);
    const quantity = productSales.reduce((sum, sale) => sum + sale.quantity, 0);
    const revenue = productSales.reduce((sum, sale) => sum + sale.totalPrice, 0);
    
    return {
      ...product,
      salesCount: productSales.length,
      quantity,
      revenue
    };
  }).sort((a, b) => b.revenue - a.revenue);

  // Vendas por forma de pagamento
  const paymentMethodStats = filteredSales.reduce((acc, sale) => {
    const method = sale.paymentMethod;
    if (!acc[method]) {
      acc[method] = { count: 0, total: 0 };
    }
    acc[method].count++;
    acc[method].total += sale.totalPrice;
    return acc;
  }, {} as Record<string, { count: number; total: number }>);

  const getPaymentMethodLabel = (method: string) => {
    const labels: { [key: string]: string } = {
      cash: 'Dinheiro',
      card: 'Cartão',
      pix: 'PIX',
      installments: 'Parcelado'
    };
    return labels[method] || method;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Estatísticas</h1>
          <p className="mt-2 text-gray-600">Análise de desempenho e relatórios</p>
        </div>
        
        <select
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
        >
          <option value="7">Últimos 7 dias</option>
          <option value="30">Últimos 30 dias</option>
          <option value="90">Últimos 90 dias</option>
          <option value="365">Último ano</option>
        </select>
      </div>

      {/* Métricas principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="bg-green-500 p-3 rounded-lg">
              <DollarSign className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Faturamento</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalRevenue)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="bg-blue-500 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Lucro Líquido</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(netProfit)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="bg-purple-500 p-3 rounded-lg">
              <BarChart3 className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Ticket Médio</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(averageTicket)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="bg-orange-500 p-3 rounded-lg">
              <Calendar className="h-6 w-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total de Vendas</p>
              <p className="text-2xl font-bold text-gray-900">{filteredSales.length}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Consignatários */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Users className="h-6 w-6 text-gray-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900">Top Consignatários</h3>
          </div>
          
          <div className="space-y-4">
            {consigneeStats.slice(0, 5).map((consignee, index) => (
              <div key={consignee.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-yellow-500 text-gray-900 rounded-full flex items-center justify-center text-sm font-bold mr-3">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{consignee.businessName}</p>
                    <p className="text-sm text-gray-600">{consignee.salesCount} vendas</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">{formatCurrency(consignee.revenue)}</p>
                  <p className="text-sm text-gray-600">Comissão: {formatCurrency(consignee.commission)}</p>
                </div>
              </div>
            ))}
            
            {consigneeStats.length === 0 && (
              <p className="text-gray-500 text-center py-4">Nenhuma venda no período</p>
            )}
          </div>
        </div>

        {/* Top Produtos */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Package className="h-6 w-6 text-gray-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900">Top Produtos</h3>
          </div>
          
          <div className="space-y-4">
            {productStats.slice(0, 5).map((product, index) => (
              <div key={product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-yellow-500 text-gray-900 rounded-full flex items-center justify-center text-sm font-bold mr-3">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{product.name}</p>
                    <p className="text-sm text-gray-600">{product.quantity} unidades vendidas</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">{formatCurrency(product.revenue)}</p>
                  <p className="text-sm text-gray-600">{product.salesCount} vendas</p>
                </div>
              </div>
            ))}
            
            {productStats.length === 0 && (
              <p className="text-gray-500 text-center py-4">Nenhuma venda no período</p>
            )}
          </div>
        </div>
      </div>

      {/* Formas de Pagamento */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Vendas por Forma de Pagamento</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(paymentMethodStats).map(([method, stats]) => (
            <div key={method} className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">{getPaymentMethodLabel(method)}</h4>
              <div className="space-y-1">
                <p className="text-sm text-gray-600">{stats.count} vendas</p>
                <p className="text-lg font-bold text-gray-900">{formatCurrency(stats.total)}</p>
                <p className="text-xs text-gray-500">
                  {((stats.total / totalRevenue) * 100).toFixed(1)}% do total
                </p>
              </div>
            </div>
          ))}
        </div>
        
        {Object.keys(paymentMethodStats).length === 0 && (
          <p className="text-gray-500 text-center py-8">Nenhuma venda no período selecionado</p>
        )}
      </div>
    </div>
  );
};

export default Estatisticas;