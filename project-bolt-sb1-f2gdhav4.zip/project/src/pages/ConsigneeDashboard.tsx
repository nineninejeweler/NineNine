import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { LogOut, Package, ShoppingCart, DollarSign, Plus, TrendingUp, Calendar, Eye, EyeOff } from 'lucide-react';
import ConsigneeSaleModal from '../components/ConsigneeSaleModal';

const ConsigneeDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const { sales, products, consignmentItems, consignees } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  if (!user || user.type !== 'consignee') {
    return null;
  }

  const consignee = consignees.find(c => c.id === user.consigneeId);
  const mySales = sales.filter(sale => sale.consigneeId === user.consigneeId);
  const myConsignments = consignmentItems.filter(item => 
    item.consigneeId === user.consigneeId && item.status === 'consigned'
  );

  const totalSales = mySales.reduce((sum, sale) => sum + sale.totalPrice, 0);
  const totalCommission = mySales.reduce((sum, sale) => sum + sale.commission, 0);
  const totalProducts = myConsignments.reduce((sum, item) => sum + item.quantity, 0);

  // Vendas por período
  const today = new Date();
  const thisMonth = mySales.filter(sale => {
    const saleDate = new Date(sale.saleDate);
    return saleDate.getMonth() === today.getMonth() && saleDate.getFullYear() === today.getFullYear();
  });
  const thisWeek = mySales.filter(sale => {
    const saleDate = new Date(sale.saleDate);
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    return saleDate >= weekAgo;
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const getPaymentMethodLabel = (method: string) => {
    const labels: { [key: string]: string } = {
      cash: 'Dinheiro',
      card: 'Cartão',
      pix: 'PIX',
      installments: 'Parcelado'
    };
    return labels[method] || method;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-500 rounded-lg flex items-center justify-center">
                <Package className="h-6 w-6 text-gray-900" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">NINE NINE</h1>
                <p className="text-sm text-gray-600">Painel do Consignatário</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{consignee?.businessName}</p>
                <p className="text-xs text-gray-600">{user.name}</p>
              </div>
              <button
                onClick={logout}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Message */}
        <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-xl p-6 mb-8 text-gray-900">
          <h2 className="text-2xl font-bold mb-2">Bem-vindo, {user.name}!</h2>
          <p className="text-gray-800">
            Gerencie suas vendas e acompanhe o desempenho do seu estabelecimento: <strong>{consignee?.businessName}</strong>
          </p>
          <p className="text-sm text-gray-700 mt-2">
            Comissão: {consignee?.commission}% • Telefone: {consignee?.phone}
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="bg-green-500 p-3 rounded-lg">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Vendido</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalSales)}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="bg-blue-500 p-3 rounded-lg">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Suas Comissões</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalCommission)}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="bg-purple-500 p-3 rounded-lg">
                <Package className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Produtos em Estoque</p>
                <p className="text-2xl font-bold text-gray-900">{totalProducts}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="bg-orange-500 p-3 rounded-lg">
                <ShoppingCart className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Vendas Realizadas</p>
                <p className="text-2xl font-bold text-gray-900">{mySales.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Performance do Mês</h3>
              <Calendar className="h-5 w-5 text-gray-400" />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Vendas este mês:</span>
                <span className="font-medium">{thisMonth.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Faturamento:</span>
                <span className="font-medium text-green-600">
                  {formatCurrency(thisMonth.reduce((sum, sale) => sum + sale.totalPrice, 0))}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Comissões:</span>
                <span className="font-medium text-blue-600">
                  {formatCurrency(thisMonth.reduce((sum, sale) => sum + sale.commission, 0))}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Últimos 7 Dias</h3>
              <TrendingUp className="h-5 w-5 text-gray-400" />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Vendas na semana:</span>
                <span className="font-medium">{thisWeek.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Faturamento:</span>
                <span className="font-medium text-green-600">
                  {formatCurrency(thisWeek.reduce((sum, sale) => sum + sale.totalPrice, 0))}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Comissões:</span>
                <span className="font-medium text-blue-600">
                  {formatCurrency(thisWeek.reduce((sum, sale) => sum + sale.commission, 0))}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Produtos em Consignação */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Produtos em Estoque</h3>
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 px-3 py-1.5 rounded-lg text-sm font-medium flex items-center space-x-1 transition-colors"
              >
                <Plus className="h-4 w-4" />
                <span>Registrar Venda</span>
              </button>
            </div>
            
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {myConsignments.map((item) => {
                const product = products.find(p => p.id === item.productId);
                return (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{product?.name}</p>
                      <p className="text-sm text-gray-600">{product?.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">Qtd: {item.quantity}</p>
                      <p className="text-sm text-green-600">{formatCurrency(product?.price || 0)}</p>
                    </div>
                  </div>
                );
              })}
              
              {myConsignments.length === 0 && (
                <div className="text-center py-8">
                  <Package className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="text-gray-500 mt-2">Nenhum produto em estoque</p>
                  <p className="text-sm text-gray-400">Entre em contato com o administrador</p>
                </div>
              )}
            </div>
          </div>

          {/* Vendas Recentes */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Histórico de Vendas</h3>
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="flex items-center space-x-1 text-sm text-gray-600 hover:text-gray-900"
              >
                {showDetails ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                <span>{showDetails ? 'Ocultar' : 'Mostrar'} detalhes</span>
              </button>
            </div>
            
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {mySales.slice(-15).reverse().map((sale) => {
                const product = products.find(p => p.id === sale.productId);
                return (
                  <div key={sale.id} className="p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{product?.name}</p>
                        <p className="text-sm text-gray-600">{formatDate(sale.saleDate)}</p>
                        {showDetails && (
                          <div className="mt-2 space-y-1">
                            <p className="text-xs text-gray-500">
                              Quantidade: {sale.quantity} • {getPaymentMethodLabel(sale.paymentMethod)}
                              {sale.installments && ` (${sale.installments}x)`}
                            </p>
                            <p className="text-xs text-gray-500">
                              Preço unitário: {formatCurrency(sale.unitPrice)}
                            </p>
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-gray-900">{formatCurrency(sale.totalPrice)}</p>
                        <p className="text-sm text-green-600">+{formatCurrency(sale.commission)}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
              
              {mySales.length === 0 && (
                <div className="text-center py-8">
                  <ShoppingCart className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="text-gray-500 mt-2">Nenhuma venda registrada</p>
                  <p className="text-sm text-gray-400">Suas vendas aparecerão aqui</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <ConsigneeSaleModal
          consigneeId={user.consigneeId!}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </div>
  );
};

export default ConsigneeDashboard;