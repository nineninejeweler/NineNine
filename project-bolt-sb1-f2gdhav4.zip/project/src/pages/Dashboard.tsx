import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Users, Package, ShoppingCart, TrendingUp, DollarSign, Crown, Plus } from 'lucide-react';
import ConsignmentModal from '../components/ConsignmentModal';

const Dashboard: React.FC = () => {
  const { consignees, products, sales, consignmentItems } = useData();
  const [isConsignmentModalOpen, setIsConsignmentModalOpen] = useState(false);

  const totalSales = sales.reduce((sum, sale) => sum + sale.totalPrice, 0);
  const totalCommission = sales.reduce((sum, sale) => sum + sale.commission, 0);
  const totalProfit = totalSales - totalCommission;
  const activeConsignments = consignmentItems.filter(item => item.status === 'consigned').length;

  const stats = [
    {
      name: 'Total de Consignatários',
      value: consignees.length,
      icon: Users,
      color: 'bg-blue-500',
    },
    {
      name: 'Produtos Cadastrados',
      value: products.length,
      icon: Package,
      color: 'bg-green-500',
    },
    {
      name: 'Vendas Realizadas',
      value: sales.length,
      icon: ShoppingCart,
      color: 'bg-purple-500',
    },
    {
      name: 'Produtos em Consignação',
      value: activeConsignments,
      icon: TrendingUp,
      color: 'bg-orange-500',
    },
  ];

  const financialStats = [
    {
      name: 'Faturamento Total',
      value: totalSales,
      icon: DollarSign,
      color: 'bg-green-600',
    },
    {
      name: 'Comissões Pagas',
      value: totalCommission,
      icon: TrendingUp,
      color: 'bg-red-500',
    },
    {
      name: 'Lucro Líquido',
      value: totalProfit,
      icon: Crown,
      color: 'bg-yellow-500',
    },
  ];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-2 text-gray-600">Visão geral do sistema de consignação</p>
        </div>
        <button
          onClick={() => setIsConsignmentModalOpen(true)}
          className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 px-4 py-2 rounded-lg font-medium flex items-center space-x-2 transition-colors"
        >
          <Plus className="h-5 w-5" />
          <span>Nova Consignação</span>
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Financial Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {financialStats.map((stat) => (
          <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(stat.value)}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Sales */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Vendas Recentes</h3>
          <div className="space-y-3">
            {sales.slice(-5).reverse().map((sale) => {
              const consignee = consignees.find(c => c.id === sale.consigneeId);
              const product = products.find(p => p.id === sale.productId);
              return (
                <div key={sale.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                  <div>
                    <p className="font-medium text-gray-900">{product?.name}</p>
                    <p className="text-sm text-gray-600">{consignee?.businessName}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{formatCurrency(sale.totalPrice)}</p>
                    <p className="text-sm text-gray-600">{new Date(sale.saleDate).toLocaleDateString('pt-BR')}</p>
                  </div>
                </div>
              );
            })}
            {sales.length === 0 && (
              <p className="text-gray-500 text-center py-4">Nenhuma venda registrada</p>
            )}
          </div>
        </div>

        {/* Top Consignees */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Consignatários</h3>
          <div className="space-y-3">
            {consignees.slice(0, 5).map((consignee) => {
              const consigneeSales = sales.filter(s => s.consigneeId === consignee.id);
              const totalSales = consigneeSales.reduce((sum, sale) => sum + sale.totalPrice, 0);
              return (
                <div key={consignee.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                  <div>
                    <p className="font-medium text-gray-900">{consignee.businessName}</p>
                    <p className="text-sm text-gray-600">{consignee.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{formatCurrency(totalSales)}</p>
                    <p className="text-sm text-gray-600">{consigneeSales.length} vendas</p>
                  </div>
                </div>
              );
            })}
            {consignees.length === 0 && (
              <p className="text-gray-500 text-center py-4">Nenhum consignatário cadastrado</p>
            )}
          </div>
        </div>
      </div>

      {isConsignmentModalOpen && (
        <ConsignmentModal onClose={() => setIsConsignmentModalOpen(false)} />
      )}
    </div>
  );
};

export default Dashboard;