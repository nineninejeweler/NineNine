import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Plus, Edit, Trash2, Search, Mail, Phone, MapPin, Store, Eye, Key, Copy, Check } from 'lucide-react';
import ConsigneeModal from '../components/ConsigneeModal';

const Consignatarios: React.FC = () => {
  const { consignees, deleteConsignee } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingConsignee, setEditingConsignee] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPasswords, setShowPasswords] = useState<{[key: string]: boolean}>({});
  const [copiedPasswords, setCopiedPasswords] = useState<{[key: string]: boolean}>({});

  const filteredConsignees = consignees.filter(consignee =>
    consignee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    consignee.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    consignee.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEdit = (consignee: any) => {
    setEditingConsignee(consignee);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este consignatário? Esta ação não pode ser desfeita.')) {
      deleteConsignee(id);
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingConsignee(null);
  };

  const togglePasswordVisibility = (id: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const copyPassword = async (password: string, id: string) => {
    try {
      await navigator.clipboard.writeText(password);
      setCopiedPasswords(prev => ({ ...prev, [id]: true }));
      setTimeout(() => {
        setCopiedPasswords(prev => ({ ...prev, [id]: false }));
      }, 2000);
    } catch (err) {
      console.error('Erro ao copiar senha:', err);
    }
  };

  const copyCredentials = async (email: string, password: string, id: string) => {
    const credentials = `Email: ${email}\nSenha: ${password}`;
    try {
      await navigator.clipboard.writeText(credentials);
      setCopiedPasswords(prev => ({ ...prev, [`${id}-full`]: true }));
      setTimeout(() => {
        setCopiedPasswords(prev => ({ ...prev, [`${id}-full`]: false }));
      }, 2000);
    } catch (err) {
      console.error('Erro ao copiar credenciais:', err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Consignatários</h1>
          <p className="mt-2 text-gray-600">Gerencie os parceiros de consignação e seus acessos</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 px-4 py-2 rounded-lg font-medium flex items-center space-x-2 transition-colors"
        >
          <Plus className="h-5 w-5" />
          <span>Novo Consignatário</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Buscar consignatários..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
        />
      </div>

      {/* Consignees Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredConsignees.map((consignee) => (
          <div key={consignee.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">{consignee.businessName}</h3>
                <p className="text-gray-600">{consignee.name}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEdit(consignee)}
                  className="p-2 text-gray-400 hover:text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors"
                  title="Editar consignatário"
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDelete(consignee.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Excluir consignatário"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center text-sm text-gray-600">
                <Mail className="h-4 w-4 mr-2 flex-shrink-0" />
                <span className="truncate">{consignee.email}</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Phone className="h-4 w-4 mr-2 flex-shrink-0" />
                {consignee.phone}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <MapPin className="h-4 w-4 mr-2 flex-shrink-0" />
                <span className="truncate">{consignee.address}</span>
              </div>
              
              {/* Access Credentials */}
              <div className="border-t border-gray-100 pt-3 mt-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700 flex items-center">
                    <Key className="h-4 w-4 mr-1" />
                    Credenciais de Acesso
                  </span>
                  <button
                    onClick={() => copyCredentials(consignee.email, consignee.password, consignee.id)}
                    className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
                    title="Copiar credenciais completas"
                  >
                    {copiedPasswords[`${consignee.id}-full`] ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </button>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">Email:</span>
                    <span className="text-xs font-mono text-gray-700 truncate ml-2">{consignee.email}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">Senha:</span>
                    <div className="flex items-center space-x-1">
                      <span className="text-xs font-mono text-gray-700">
                        {showPasswords[consignee.id] ? consignee.password : '••••••••'}
                      </span>
                      <button
                        onClick={() => copyPassword(consignee.password, consignee.id)}
                        className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
                        title="Copiar senha"
                      >
                        {copiedPasswords[consignee.id] ? (
                          <Check className="h-3 w-3 text-green-500" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </button>
                      <button
                        onClick={() => togglePasswordVisibility(consignee.id)}
                        className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
                        title={showPasswords[consignee.id] ? "Ocultar senha" : "Mostrar senha"}
                      >
                        <Eye className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <span className="text-sm text-gray-600">Comissão</span>
                <span className="font-medium text-gray-900">{consignee.commission}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredConsignees.length === 0 && (
        <div className="text-center py-12">
          <Store className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhum consignatário encontrado</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchTerm ? 'Tente ajustar sua busca.' : 'Comece adicionando um novo consignatário.'}
          </p>
        </div>
      )}

      {isModalOpen && (
        <ConsigneeModal
          consignee={editingConsignee}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
};

export default Consignatarios;