import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Consignatarios from './pages/Consignatarios';
import Produtos from './pages/Produtos';
import Vendas from './pages/Vendas';
import Estatisticas from './pages/Estatisticas';
import ConsigneeLogin from './pages/ConsigneeLogin';
import ConsigneeDashboard from './pages/ConsigneeDashboard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/consignee-login" element={<ConsigneeLogin />} />
              <Route path="/consignee-dashboard" element={<ConsigneeDashboard />} />
              <Route path="/" element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }>
                <Route index element={<Dashboard />} />
                <Route path="consignatarios" element={<Consignatarios />} />
                <Route path="produtos" element={<Produtos />} />
                <Route path="vendas" element={<Vendas />} />
                <Route path="estatisticas" element={<Estatisticas />} />
              </Route>
            </Routes>
          </div>
        </Router>
      </DataProvider>
    </AuthProvider>
  );
}

export default App;